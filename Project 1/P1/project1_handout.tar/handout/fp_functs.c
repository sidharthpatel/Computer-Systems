/* Fill in your Name and GNumber in the following two comment fields
 * Name:
 * GNumber:
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fp.h"

/* Checks if -0.0 on input value.
 * Returns 1 if -0.0
 * Returns 0 otherwise.
 */
static int is_negative_zero(float val) {
  return (val == 0.0 && ((1.f / val) < 0));
}

/* input: float value to be represented
 * output: integer representation of the input float
 *
 * Perform this the same way we did in class -
 *   either dividing or multiplying the value by 2
 *   until it is in the correct range (between 1 and 2).
 *
 * Follow the Project Documentation for Instructions
 */
int compute_fp(float val) {
  /* Implement this function */

  return 125;
}

/* input: integer representation of our floats
 * output: float value represented by our integer encoding
 *
 * Follow the Project Documentation for Instructions
 */
float get_fp(int val) {
  /* Implement this function */

  return 2.0;
}

/* input: Two integer representations of our floats
 * output: The multiplication result in our integer representation
 *
 * You must implement this using hte algorithm described in class:
 *   Add the exponents: E = E1 + E2
 *   Multiply the Frac Values: M = M1 * M2
 *   If M is not in a valid range, adjust M and E.
 *
 * Follow the Project Documentation for Instructions
 */
int mult_vals(int source1, int source2) {
  /* Implement this function */

  return 125;
}

/* input: Two integer representations of our floats
 * output: The addition result in our integer representation
 *
 * You must implement this using hte algorithm described in class:
 *   If needed, adjust the numbers to get the same exponent E
 *   Add the two fractional parts: F = F1' + F2
 *   (where F1' is the adjusted F1 if needed)
 *   Adjust the sum F and E so that F is in the correct range.
 *
 * Follow the Project Documentation for Instructions
 */
int add_vals(int source1, int source2) {
  /* Implement this function */

  return 125;
}
