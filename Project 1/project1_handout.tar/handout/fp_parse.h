/* Do Not Modify This File */
#ifndef FP_PARSE_H
#define FP_PARSE_H

#define ASSIGN 33 
#define PLUS 27
#define PRINT 28
#define DISPLAY 29
#define EOLN 30
#define FLOAT 31
#define MULT 32
#define SKIP 33
#define EXIT 34

#endif
