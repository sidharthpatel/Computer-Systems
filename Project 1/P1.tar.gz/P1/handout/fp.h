/* Do Not Modify This File */
#ifndef FP_H
#define FP_H

#define EXPONENT_BITS 5
#define FRACTION_BITS 9

#define DENORMALIZED 0
#define SPECIAL 1
#define SIGNED 1

#endif
